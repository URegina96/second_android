package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class RecievedMsgActivity extends AppCompatActivity {
    private TextView textViewRecievedMsg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recieved_msg);
        textViewRecievedMsg = findViewById(R.id.textViewRecievedMsg);
        Intent intent = getIntent();
        String msg = intent.getStringExtra("msg");
        textViewRecievedMsg.setText(msg);
    }
}